class SignalProcessor ( object ):
    def __init__ (self, data):
        self.data = data